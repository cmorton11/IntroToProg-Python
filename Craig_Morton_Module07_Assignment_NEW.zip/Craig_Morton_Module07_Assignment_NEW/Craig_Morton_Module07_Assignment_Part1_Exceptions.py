# ------------------------------------------------- #
# Title: Module 07 Assignment Part 1/2
# Dev:   Craig Morton
# Date:  5/13/2018
# Change Log: CraigM, 5/13/2018, Exception Handling example - Division Program
#  ------------------------------------------------ #

while True:  # Loop that allows the user to continue dividing numbers until they choose to exit

    try:  # Initiates exception handling
        divNum1 = int(input("Please enter the number you would like to divide: "))  # User value one
        divNum2 = int(input("Please enter the number you would like to divide by: "))  # User value two
        print("%d / %d = %f" % (divNum1, divNum2, divNum1/divNum2))  # Quotient of user values one and two
    except(ValueError, ZeroDivisionError):  # Generates an exception if the value is not an integer or division is by 0
        print("There was an error!  Please make sure you are entering whole numbers only and do not divide by 0")
    usrResponse = input("type 'Exit' to quit this program or press Enter to continue: ")  # User option to escape
    if usrResponse.lower() == "exit":
        break
    else:
        continue

