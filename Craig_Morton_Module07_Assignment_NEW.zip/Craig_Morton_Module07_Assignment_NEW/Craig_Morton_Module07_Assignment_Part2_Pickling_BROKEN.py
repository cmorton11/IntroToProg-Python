# ------------------------------------------------- #
# Title: Module 07 Assignment Part 2/2
# Dev:   Craig Morton
# Date:  5/14/2018
# Change Log: CraigM, 5/14/2018, Pickling Example - Mythical creatures
#  ------------------------------------------------- #

# Pseudo Code # ------------------------

# Declare modules to import and/or global variables
# Define mythical creature mix, name and territory
# Pickle to binary file
# Unpickle from binary file
# Shelve to binary file
# Retrieve from shelve binary file

# Data # ------------------------

# No global variables defined.  Each variable is encapsulated within function scope
import pickle  # Imports the pickle module for data pickling to file
import shelve  # Imports the shelve module for shelf storage and access to pickled objects in shelf file
import time  # Imports the time module to leverage time features

# Processing # ------------------------


def PicklingLists():
    """"This function pickles the mix, creature and territory lists to the pickling1 file"""
    time.sleep(2)  # Provides a 2 second delay before following statement execution for improved UX
    pickleFile = open("pickling1.dat", "wb")  # Open file connection and write to binary file
    mix = ["Lion/Tiger", "Bear/Eagle", "Shark/Dolphin"]  # Lists for pickling
    creature = ["Liger ", "Beagle", "Sharphin"]
    territory = ["Land", "Air", "Water"]
    pickle.dump(mix, pickleFile)  # Stores each of the three lists in the pickling1.dat file
    pickle.dump(creature, pickleFile)
    pickle.dump(territory, pickleFile)
    pickleFile.close()  # Closes file connection


def UnpicklingLists():
    """"This function unpickles the mix, creature and territory lists from the pickling1 file"""
    time.sleep(2)
    pickleFile = open("pickling1.dat", "rb")  # Open file connection and ready from binary file
    mix = pickle.load(pickleFile)  # Retrieves and unpickles each of the three lists
    creature = pickle.load(pickleFile)
    territory = pickle.load(pickleFile)
    print(mix)
    print(creature)
    print(territory)
    pickleFile.close()


def ShelvingLists():
    """"This function shelves the mix, creature and territory lists together"""
    time.sleep(2)
    shelveFile = shelve.open("pickling2.dat")
    shelveFile["Mix"] = ["Lion/Tiger", "Bear/Eagle", "Shark/Dolphin"]
    shelveFile["Creature"] = ["Liger ", "Beagle", "Sharphin"]
    shelveFile["Territory"] = ["Land", "Air", "Water"]
    shelveFile.sync()


def ShelveRetrieve():
    """"This function retrieves the mix, creature and territory lists from the pickling2 file"""
    time.sleep(2)
    shelveFile = shelve.open("pickling2.dat")
    print("Mix -", shelveFile["mix"])
    print("Creature -", shelveFile["creature"])
    print("Territory -", shelveFile["territory"])
    shelveFile.close()

# Main Program I/O # ------------------------

print("Pickling lists...\n")
PicklingLists()

print("Unpickling lists:\n")
UnpicklingLists()

print("\nShelving lists...\n")
ShelvingLists()

print("Retrieving lists from a shelved file:\n")
ShelveRetrieve()

input("\n\nPlease press Enter to exit!. ")


