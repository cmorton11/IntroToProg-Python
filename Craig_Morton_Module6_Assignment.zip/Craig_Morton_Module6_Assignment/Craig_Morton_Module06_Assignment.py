# ------------------------------------------------- #
# Title: Module 6 Assignment
# Dev:   Craig Morton
# Date:  5/6/2018
# Change Log: CraigM, 5/6/2018, Creating task management program for Module 6
# Including: Class and associated functions
#  ------------------------------------------------- #

# -- Pseudo Data -- #

# Declare variables and constants
# objFileName = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strChoice = Capture the user option selection

# -- Pseudo Processing -- #

# Step 1 - When the program starts, load any data you have in a text file called ToDo.txt into a Python Dictionary
# Step 2 - Display a menu of choices to the user
# Step 3 - Display all todo items to user
# Step 4 - Add a new item to the list/Table
# Step 5 - Remove a new item to the list/Table
# Step 6 - Save tasks to the ToDo.txt file
# Step 7 - Exit program

# -- Pseudo Presentation/Main Program -- #

# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert data(Step 4)
# User can delete data(Step 5)
# User can save to file (Step 6)
# User can exit program (Step 7)

# -- Data -- # --------------------------------------------------------------------

# Global variables
objFileName = "C:\_PythonClass\Todo.txt"
strData = ""
dicRow = {}
lstTable = []
strChoice = None

# -- Processing -- # --------------------------------------------------------------


class TaskList:  # Declares the class name

    @staticmethod  # The staticmethod object acts as a wrapper to provide function immutability.
    def ObjFileRead():  # Declares the function name
        """ This function reads the data from the ToDo.txt file and writes it to the task/priority table """
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()

    @staticmethod
    def MenuOptions():
        """ This function displays a menu to the user for interaction """  # Docstring provides function definition
        print("""
            Menu of Options
            1)  Show current data
            2)  Add a new item
            3)  Remove an existing item
            4)  Save Data to File
            5)  Exit Program
            """)

    @staticmethod
    def UserOption1():
        """ This function displays the contents of the list to the user """
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
            print("===========================================")

    @staticmethod
    def UserOption2():
        """ This function allows the user to add a new task/priority """
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)

    @staticmethod
    def UserOption3():
        """ This function allows the user to remove a task/priority """
        strKeyToRemove = input("Which task would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        print("======= The current items ToDo are: =======")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("===========================================")

    @staticmethod
    def UserOption4():
        """ This function allows the user to save new tasks/priorities to file """
        print("======= The current items ToDo are: =======")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("===========================================")
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")

# -- Presentation/Main Program -- # --------------------------------------------------------------

# Step 1 - When the program starts, load any data you have in a text file called ToDo.txt into a Python Dictionary
TaskList.ObjFileRead()

# Step 2 - Display a menu of choices to the user
while True:
    TaskList.MenuOptions()
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))

    # Step 3 - Display all todo items to user
    if (strChoice.strip() == '1'):
        TaskList.UserOption1()

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        TaskList.UserOption2()

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice.strip() == '3'):
        TaskList.UserOption3()

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice.strip() == '4'):
        TaskList.UserOption4()

    # Step 7 - Exit program
    elif (strChoice.strip() == '5'):
        input("Thank you for using the task management program!  Please press enter to exit. ")
        break



