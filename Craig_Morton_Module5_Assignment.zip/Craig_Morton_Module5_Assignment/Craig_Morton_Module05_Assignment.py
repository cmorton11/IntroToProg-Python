# ------------------------------------------------- #
# Title: Module 5 - Working with Dictionaries
# Dev:   Craig Morton
# Date:  4/29/2018
# ChangeLog: CraigM, 4/29/2018, Creating task management program
#   CraigM, 4/29/2018, Creating task management program
#   CraigM, Added code to complete Module 5
# ------------------------------------------------- #

#-- Data --#
# declare variables and constants
# tskFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program

# ------------------------------------------------------------#
# Step 1

# Write the following data to ToDo.txt:
# Clean House, low
# Pay Bills, high

lstTable = []  # Define list variable.

tskFile = open("C:\\Users\\cmort\\Desktop\\ToDo.txt", "w")  # Opens connection to ToDo.txt.
tskFile.write("Clean House, Low\n")  # Writes data to Todo.txt.
tskFile.write("Pay Bills, High\n")  # Writes data to Todo.txt.
tskFile.close()  # Closes file connection.

# ------------------------------------------------------------#

# When the program starts, load each "row" of data from "ToDo.txt" into a Python dictionary.
# Add each dictionary "row" to a python list "table".

tskFile = open("C:\\Users\\cmort\\Desktop\\ToDo.txt", "r")  # Opens connection to ToDo.txt and reads content.
for strData in tskFile:  # loops for data in ToDo.txt
    dicRow = {(strData.split(",")[0]).strip(): (strData.split(",")[1]).strip()}  # Defines dictionary row.
    lstTable.append(dicRow)  # Nests dictionary row into a list and generates table contents.

# ------------------------------------------------------------#
# Step 2 - User can see a Menu

# Display Contents of the list to the user.
# Display a menu of choices to the user.

print("                                      ")  # Improved UX
print("======================================")
print("Welcome to your Task Priority program!")
print("======================================")
print("                                      ")
print("The current contents of your task priority list:" + str(lstTable))  # Displays current list contents.
print("                                      ")
print("Please select one of the following menu options:")

while True:
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)

    strChoice = input("Which option would you like to perform? [1 to 5]: ")  # Provide user options.
    print()  # adding a new line

# ------------------------------------------------------------#
# Step 3 - Show the current items in the table

    if strChoice.strip() == '1':  # Option to display current table.
        print(lstTable)  # Prints table contents.

# ------------------------------------------------------------#
# Step 4 - Add a new item to the list/Table

    elif strChoice.strip() == '2':  # Option to add tasks.
        usrSelection1 = input("Please add a new task: ")  # Request user enter additional task.
        usrSelection2 = input("Please add a new priority: ")  # Request user enter additional priority.
        dicNewRow = {usrSelection1: usrSelection2}  # Variable creating new dictionary item.
        lstTable.append(dicNewRow)  # adding new dictionary item to list.

# ------------------------------------------------------------#
# Step 5 - Remove a new item to the list/Table

    elif strChoice == '3':  # Option to remove tasks.
        print(lstTable)  # Prints current list for user reference.
        usrRemove = int(input("Please select the number of the item you wish to remove: "))  # Requests task removal.
        if usrRemove in lstTable:  # Checks for user entry in the list.
            del lstTable[usrRemove]  # deletes the user entry from the list.
        print("Your entry has been removed")  # Confirms task has been removed.

# ------------------------------------------------------------#
# Step 6 - Save tasks to the ToDo.txt file

    elif strChoice == '4':  # Option to save table to file.
        tskFile = open("C:\\Users\\cmort\\Desktop\\ToDo.txt", "w+")  # Overwrites contents of ToDo.txt file.
        tskFile.write(str(lstTable))  # writes table to file.
        print("Your data has been saved to the file ToDo.txt")  # User confirmation of saved data.
        tskFile.close()  # Closes file connection.

# ------------------------------------------------------------#
# Step 7 - Exit program

    elif strChoice == '5':  # Option to exit program.
        print("Goodbye!")  # Confirms program has closed.
        break  # Breaks program connection.
    else:
        print("Invalid entry!")  # Challenges user if entries are outside of defined range.

# ------------------------------------------------------------#


